// ══════════════════════════════════════
//  app.js  —  Vera Candles application logic
// ══════════════════════════════════════

// ── State ──────────────────────────────
let cart = 0;
let currentFilter = 'all';
let currentShop   = [];   // filled after data.js loads
let quizStep      = 0;
let quizAnswers   = [];

// ── Section Loader ──────────────────────
// Fetches each section HTML file and injects it into its mount point.
// Returns a Promise that resolves when ALL sections are loaded.
function loadAllSections() {
  const sections = ['home', 'candles', 'shop', 'about', 'contact'];

  const promises = sections.map(name => {
    return fetch(`sections/${name}.html`)
      .then(res => {
        if (!res.ok) throw new Error(`Failed to load sections/${name}.html`);
        return res.text();
      })
      .then(html => {
        document.getElementById(`${name}-section`).innerHTML = html;
      })
      .catch(err => console.error(err));
  });

  return Promise.all(promises);
}

// ── App Init ────────────────────────────
// Called once all sections are loaded.
function initApp() {
  currentShop = [...shopData];   // shopData comes from data.js

  // Close modals on backdrop click
  ['login-modal', 'quiz-modal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('click', function(e) {
        if (e.target === this) this.style.display = 'none';
      });
    }
  });
}

// ── Navigation ──────────────────────────
function showSection(name) {
  const allNames = ['home', 'candles', 'shop', 'about', 'contact'];

  allNames.forEach(s => {
    const el = document.getElementById(`${s}-section`);
    if (!el) return;

    if (s === name) {
      el.style.display = 'block';
      if (s !== 'home') el.classList.add('active');
    } else {
      el.style.display = 'none';
      el.classList.remove('active');
    }
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Render dynamic content when entering a section
  if (name === 'candles') renderCandles('all');
  if (name === 'shop')    renderShop();
}

// ── Candles Section ─────────────────────
function renderCandles(filter) {
  const grid = document.getElementById('candles-grid');
  if (!grid) return;

  const data = filter === 'all'
    ? candleData
    : candleData.filter(c => c.scent === filter);

  grid.innerHTML = data.map(c => `
    <div class="candle-card">
      <img src="${c.img}" alt="${c.name}">
      <div class="candle-card-body">
        <div class="candle-card-name">${c.name}</div>
        <div class="candle-card-desc">${c.desc}</div>
        <div class="candle-card-footer">
          <div class="candle-price">$${c.price}</div>
          ${c.tag
            ? `<span class="candle-tag ${c.tag === 'new' ? 'new' : c.tag === 'sale' ? 'sale' : ''}">${c.tag}</span>`
            : ''}
        </div>
        <button class="add-cart-btn" onclick="addToCart('${c.name}')">+ Add to Cart</button>
      </div>
    </div>
  `).join('');
}

function filterCandles(btn, filter) {
  document.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentFilter = filter;
  renderCandles(filter);
}

// ── Shop Section ────────────────────────
function renderShop() {
  const slider = document.getElementById('price-slider');
  const maxPrice = slider ? parseInt(slider.value) : 120;
  const grid = document.getElementById('shop-grid');
  if (!grid) return;

  const filtered = currentShop.filter(i => i.price <= maxPrice);

  grid.innerHTML = filtered.map(i => `
    <div class="shop-item">
      <img src="${i.img}" alt="${i.name}">
      <button class="wishlist-btn" onclick="showToast('Added to wishlist 🤍')">♡</button>
      <div class="shop-item-body">
        <div class="shop-item-name">${i.name}</div>
        <div class="shop-item-price">$${i.price}</div>
        <button class="add-cart-btn" onclick="addToCart('${i.name}')">+ Add to Cart</button>
      </div>
    </div>
  `).join('');
}

function updatePrice(el) {
  const display = document.getElementById('price-display');
  if (display) display.textContent = `Up to $${el.value}`;
  renderShop();
}

function applyShopFilter() {
  renderShop();
}

function sortShop(val) {
  if (val === 'price-low')  currentShop = [...shopData].sort((a, b) => a.price - b.price);
  else if (val === 'price-high') currentShop = [...shopData].sort((a, b) => b.price - a.price);
  else if (val === 'newest')     currentShop = [...shopData].reverse();
  else                           currentShop = [...shopData];
  renderShop();
}

// ── Cart ────────────────────────────────
function addToCart(name) {
  cart++;
  ['cart-count', 'cart-count-c', 'cart-count-s', 'cart-count-a', 'cart-count-ct'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = cart;
  });
  showToast(`🕯️ "${name}" added to cart`);
}

// ── Toast ────────────────────────────────
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Login Modal ──────────────────────────
function openLoginModal() {
  document.getElementById('login-modal').style.display = 'flex';
}
function closeLoginModal() {
  document.getElementById('login-modal').style.display = 'none';
}

// ── Quiz Modal ───────────────────────────
function openQuizModal(e) {
  if (e) e.preventDefault();
  quizStep = 0;
  quizAnswers = [];
  document.getElementById('quiz-modal').style.display = 'flex';
  renderQuizStep();
}
function closeQuizModal() {
  document.getElementById('quiz-modal').style.display = 'none';
}

function renderQuizStep() {
  const step = quizSteps[quizStep];   // quizSteps from data.js
  document.getElementById('quiz-title').textContent = step.q;
  document.getElementById('quiz-body').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      ${step.opts.map((o, i) => `
        <button onclick="quizAnswer(${i})"
          style="padding:16px;border:1px solid #ddd;border-radius:14px;
                 background:rgba(255,255,255,0.6);cursor:pointer;
                 font-family:'Sora',sans-serif;font-size:14px;text-align:left;transition:all 0.2s;"
          onmouseover="this.style.background='rgba(17,17,17,0.06)'"
          onmouseout="this.style.background='rgba(255,255,255,0.6)'">${o}</button>
      `).join('')}
    </div>
    <div style="font-family:'Sora',sans-serif;font-size:12px;color:#bbb;text-align:center;margin-top:20px;">
      Step ${quizStep + 1} of ${quizSteps.length}
    </div>
  `;
}

function quizAnswer(i) {
  quizAnswers.push(i);
  quizStep++;

  if (quizStep < quizSteps.length) {
    renderQuizStep();
  } else {
    const result = quizResults[quizAnswers[0] % quizResults.length];  // quizResults from data.js
    document.getElementById('quiz-title').textContent = '✨ Your Perfect Match';
    document.getElementById('quiz-body').innerHTML = `
      <div style="text-align:center;padding:20px 0;">
        <div style="font-family:'Safira';font-size:28px;letter-spacing:2px;margin-bottom:8px;">${result.vibe}</div>
        <div style="font-family:'Perandory';font-size:15px;color:#888;letter-spacing:2px;">${result.sub}</div>
        <button onclick="closeQuizModal();showSection('shop')"
          style="margin-top:28px;padding:14px 28px;background:#111;color:#fff;border:none;
                 border-radius:14px;font-family:'Abiah';font-size:15px;letter-spacing:2px;cursor:pointer;">
          Shop Now →
        </button>
      </div>
    `;
  }
}

// ── Contact Form ─────────────────────────
function submitForm() {
  const name  = document.getElementById('f-name')?.value.trim();
  const email = document.getElementById('f-email')?.value.trim();
  if (!name || !email) {
    showToast('Please fill in your name and email.');
    return;
  }
  document.getElementById('form-area').style.display = 'none';
  document.getElementById('form-success').style.display = 'block';
}
