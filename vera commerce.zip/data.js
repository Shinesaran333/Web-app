// ══════════════════════════════════════
//  data.js  —  Vera Candles product data
// ══════════════════════════════════════

const candleData = [
  {
    name: 'Vanilla Serenity',
    scent: 'sweet',
    desc: 'Warm vanilla bean & cashmere musk. Deeply comforting.',
    price: 38,
    tag: 'bestseller',
    img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg'
  },
  {
    name: 'Amber Glow',
    scent: 'woody',
    desc: 'Aged amber, sandalwood, and a whisper of tobacco.',
    price: 42,
    tag: 'new',
    img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg'
  },
  {
    name: 'Lavender Dreams',
    scent: 'floral',
    desc: 'Provence lavender, clean linen, and a touch of vanilla.',
    price: 36,
    tag: '',
    img: 'https://img.freepik.com/free-photo/candle-with-soft-natural-lighting_24972-3055.jpg'
  },
  {
    name: 'Cedar & Rain',
    scent: 'fresh',
    desc: 'Pacific cedar, petrichor, and green moss after rainfall.',
    price: 44,
    tag: 'new',
    img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg'
  },
  {
    name: 'Rose Noir',
    scent: 'floral',
    desc: 'Midnight rose, black pepper, patchouli undertones.',
    price: 48,
    tag: 'sale',
    img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg'
  },
  {
    name: 'Cardamom Kiss',
    scent: 'spice',
    desc: 'Cardamom, clove bud, and golden honey on warm wood.',
    price: 40,
    tag: '',
    img: 'https://img.freepik.com/free-photo/candle-with-soft-natural-lighting_24972-3055.jpg'
  },
  {
    name: 'Sea Breeze',
    scent: 'fresh',
    desc: 'Amalfi citrus, sea salt, and driftwood.',
    price: 34,
    tag: '',
    img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg'
  },
  {
    name: 'Smoked Oud',
    scent: 'woody',
    desc: 'Deep oud, smoked resin, midnight woods.',
    price: 56,
    tag: 'new',
    img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg'
  },
];

const shopData = [
  { name: 'Vanilla Serenity',  type: 'Jar Candles',    price: 38,  img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg' },
  { name: 'Amber Glow Set',    type: 'Gift Sets',       price: 85,  img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg' },
  { name: 'Lavender Taper',    type: 'Taper Candles',   price: 28,  img: 'https://img.freepik.com/free-photo/candle-with-soft-natural-lighting_24972-3055.jpg' },
  { name: 'Cedar Pillar',      type: 'Pillar Candles',  price: 52,  img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg' },
  { name: 'Rose Noir Jar',     type: 'Jar Candles',     price: 48,  img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg' },
  { name: 'The Vera Gift Set', type: 'Gift Sets',       price: 110, img: 'https://img.freepik.com/free-photo/candle-with-soft-natural-lighting_24972-3055.jpg' },
  { name: 'Sea Breeze Pillar', type: 'Pillar Candles',  price: 44,  img: 'https://img.freepik.com/free-photo/two-candles-with-overlapping-shadows_24972-3035.jpg' },
  { name: 'Smoked Oud Jar',   type: 'Jar Candles',     price: 56,  img: 'https://img.freepik.com/free-photo/candle-with-shadow-emphasizing-minimal-elegance_24972-3025.jpg' },
];

// Quiz questions + results
const quizSteps = [
  { q: "What's your vibe?",      opts: ['🌙 Cosy & Warm','🌿 Fresh & Clean','🌸 Floral & Soft','🔥 Bold & Smoky'] },
  { q: 'Best candle moment?',    opts: ['Morning routine','Evening wind-down','Dinner party','Meditation'] },
  { q: 'Favourite season?',      opts: ['🌸 Spring','☀️ Summer','🍂 Autumn','❄️ Winter'] },
];

const quizResults = [
  { vibe: 'You are a Vanilla Serenity.', sub: 'Warm, familiar, and deeply comforting.' },
  { vibe: 'You are a Sea Breeze.',       sub: 'Crisp, refreshing, and clear-headed.' },
  { vibe: 'You are a Rose Noir.',        sub: 'Romantic, layered, and quietly complex.' },
  { vibe: 'You are a Smoked Oud.',       sub: 'Intense, memorable, and utterly distinctive.' },
];
